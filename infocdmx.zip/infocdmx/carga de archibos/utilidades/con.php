<?php
$servername = "localhost";
$database = "GVOT";
$username = "root";
$password = "";
//conecion
$conn = mysqli_connect($servername, $username, $password, $database);
//
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//echo "ce conecto exitosa mente";
mysqli_close($conn);

 ?>
