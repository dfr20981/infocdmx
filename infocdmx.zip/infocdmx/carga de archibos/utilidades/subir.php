<?php
//error
error_reporting(-1);
ini_set("display_errors", 1);
//petision del nombre y balidacion
$nombre_archivo = $_FILES['file01']['name'];
$tipo_arvhivo = $_FILES['file01']['type'];
//balida el nombre
if (move_uploaded_file($_FILES[file001][tmp_nsme], $nombre_archivo)) {
  // code...
  $extension = substr(strrchr($nombre_archivo, "."), 1);
//permisos de archibos
//formatos permitodos
  $archibo_permitido1 = "image/jpg";
  $archibo_permitido2 = "image/jpeg";
  $archibo_permitido3 = "application/xml";
  $archibo_permitido4 = "application/DOC";
  $archibo_permitido5 = "application/ppt";
  $archibo_permitido6 = "application/ppt";
  $archibo_permitido7 = "application/zip";
  $archibo_permitido8 = "application/pdf";
//comparcion de multiples permisos
  if ($archibo_permitido >= $volumen_min AND $archibo_permitido <= $volumen_max AND ($tipo_arvhivo == $archibo_permitido1 OR
   $tipo_arvhivo == $archibo_permitido2 OR $tipo_arvhivo == $archibo_permitido3 OR
   $tipo_arvhivo == $archibo_permitido4 OR $tipo_arvhivo == $archibo_permitido5 OR
   $tipo_arvhivo == $archibo_permitido6 OR $tipo_arvhivo == $archibo_permitido7 OR
   $tipo_arvhivo == $archibo_permitido8  )){
    // code...

    //peticion del metodo post
    $new_nombre = $_POST["elnombre"];
    $carpeta = "fotos";
    //extencion de archibos
    $archibo_renombrado = "$new_nombre" . "$extension";
    rename($nombre_archivo, $nombre_archivo);
    if (copy("$archibo_renombrado", "$carpeta/$archibo_renombrado"))
    {
      // code...
      //el chicrerro se a copidado en la direcion
      echo "el fichero ha sido copiado exitosa mente. <br />
      <a target=\"_blank\" href=\"$carpeta/$archibo_renombrado\>"$archibo_renombrado</A><br />
      $vol_archi kb;
      //
    }else {
      // code...
      echo "el fichero no se ha podido copiar";
    }
  }

}
 ?>
