<?php
//echo "hola mundo";
require 'con.php';
//inicio de Sesion
session_start();

//requisitos de sesion
$email = $_POST["correo"];
$pass = $_POST["password"];
/*
$sql = sprintf("SELECT * FROM usuario WHERE email='%s' AND pass = '%s'", mysql_real_escape_string($email), mysql_real_escape_string($pass));
$resultado = $conn->query($sql);

if ($resultado) {
  // code...
  $_SESSION['email'] = $email;

  header("HTTP/1.1 302 Moved Temporarily");
  header("Location: ../index.php");
}else {
  echo "el email o el password esta mal fabor de verificar";
}
*/
 ?>
