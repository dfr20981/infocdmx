<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>admin</title>
  </head>
  <body>
    <section>
    <form enctype="multipart/form-data" class="" action="index.html" method="post" id="filmulti">
      <div class="">
        <input type="file" name="" value="">
        <button type="submit" name="button"></button>
      </div>
    </form>
    </section>
  </body>
</html>
