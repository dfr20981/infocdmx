<?php
	session_start();
	require_once 'exeSp.php';
	  

	if($_POST['user']!='' && $_POST['pws']!=''){
   		$query="CALL sp_validarUsuario('".$_POST['user']."','".$_POST['pws']."');";
   		//echo $query;
   		$json=dbExec::exec($query);//clase read QueryExe
   		$obj = json_decode($json);

   		$error=(($obj->error)?1:0);
   		
		$_SESSION['SESS_ERROR']=$error;

   		if($_SESSION['SESS_ERROR']==1){
   			echo 'A';

   			$_SESSION['SESS_MEMBER_ID'] = 0;
			$_SESSION['SESS_USER'] ='';
			$_SESSION['SESS_MSG']=$obj->msg;
		}else{
			echo 'B';

			$res=$obj->res;

   			$_SESSION['SESS_MEMBER_ID'] =$res->id;
			$_SESSION['SESS_USER'] = $res->user;
			//$_SESSION['SESS_Cargo'] = $obj['activo'];
			//$_SESSION['SESS_Cargo'] = $obj['activo'];
   		}
	}else{
		echo 'C';

		$_SESSION['SESS_ERROR']=1;
		$_SESSION['SESS_MSG']="No ingreso ni Usuario y/o Contraseña";
	}

	header("location: ../index.php");
	exit();

?>