  $("#boton").on("click", function(){
    var miArchobo = $("#archibos").prop('files')[0];
    var datoDepende = new ForData;
    datoDepende.append("archibos",datoDepende);
    var destino="con.php";

    $.ajax({
      type: 'POST',
      cache: false,
      contentType: false,
      processdata: false,
      data:datoDepende,
      url:destino
    }).done(function(data){
      alert(data);
    }).fail(function(){
      alert('el archibo no se pudo cargar');
    });
  });
