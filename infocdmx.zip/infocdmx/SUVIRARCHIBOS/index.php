<?php

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  </head>
  <body>
    <nav>

    </nav>
    <section>
      <form enctype="multipart/form-data" class="" action="index.html" method="post">
        <input type="file" id="archibos" name="file[]" multiple value=""><br><br>
        <input type="button" id="boton" name="" value="">
      </form>
    </section>
    <footer></footer>
    <!--manda a llamra el ajax para subir multiples archibos-->
    <script src="js/ajax.js" type="text/javascript"></script>
    
  </body>
</html>
