<?php
require_once('control/db.php');
require_once('control/control.php');
require_once('control/subir.php');
  $url = "";

  $doc = $url . gvot($_FILE)
 ?>
