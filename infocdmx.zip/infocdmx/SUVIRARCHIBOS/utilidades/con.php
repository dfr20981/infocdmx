<?php
if (isset($_FILES["archibo"])) {
  // code...
  $archivo = $_FILES
}
?>
