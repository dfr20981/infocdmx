<form action="sube.php" method="post" enctype="multipart/form-data" >
                    <div class="row">
                        <div class="col s12 m6 l3">
                            <div class="card horizontal">
                                  <div class="card-stacked">
                                    <div class="card-content">
                                        <h5>Articulo</h5>
                                    </div>
                                    <div class="card-action">
                                        <select class="browser-default" name= "articulo" id= "articulo">
                                        <option value="" disabled selected>Selecciona</option>
                                        <option value="Art121">Articulo 121</option>
                                        <option value="Art133">Articulo 133</option>
                                        <option value="Art122">Articulo 122</option>
                                        <option value="Art139">Articulo 139</option>
                                        <option value="Art140">Articulo 140</option>
                                        <option value="Art143">Articulo 143</option>
                                        <option value="Art145">Articulo 145</option>
                                        <option value="Art146">Articulo 146</option>
                                        <option value="Art147">Articulo 147</option>
                                      </select>

                                    </div>
                                  </div>
                            </div>
                        </div>
                        <div class="col s12 m6 l3">
                            <div class="card horizontal">
                                  <div class="card-stacked">
                                    <div class="card-content">
                                        <h5>Fraccion</h5>
                                    </div>
                                    <div class="card-action">
                                    <select class="browser-default" name="fraccion">
                                      <option value="" disabled selected>Selecciona</option>
                                      <option value="Fr01">Fraccion 1</option>
                                      <option value="Fr02">Fraccion 2</option>
                                      <option value="Fr03">Fraccion 3</option>
                                      <option value="Fr04">Fraccion 4</option>
                                      <option value="Fr05">Fraccion 5</option>
                                      <option value="Fr06">Fraccion 6</option>
                                      <option value="Fr07">Fraccion 7</option>
                                      <option value="Fr08">Fraccion 8</option>
                                      <option value="Fr09">Fraccion 9</option>
                                      <option value="Fr10">Fraccion 10</option>
                                      <option value="Fr11">Fraccion 11</option>
                                      <option value="Fr12">Fraccion 12</option>
                                      <option value="Fr13">Fraccion 13</option>
                                      <option value="Fr14">Fraccion 14</option>
                                      <option value="Fr15">Fraccion 15</option>
                                      <option value="Fr16">Fraccion 16</option>
                                      <option value="Fr17">Fraccion 17</option>
                                      <option value="Fr18">Fraccion 18</option>
                                      <option value="Fr19">Fraccion 19</option>
                                      <option value="Fr20">Fraccion 20</option>
                                      <option value="Fr21">Fraccion 21</option>
                                      <option value="Fr22">Fraccion 22</option>
                                      <option value="Fr23">Fraccion 23</option>
                                      <option value="Fr24">Fraccion 24</option>
                                      <option value="Fr25">Fraccion 25</option>
                                      <option value="Fr26">Fraccion 26</option>
                                      <option value="Fr27">Fraccion 27</option>
                                      <option value="Fr28">Fraccion 28</option>
                                      <option value="Fr29">Fraccion 29</option>
                                      <option value="Fr30">Fraccion 30</option>
                                      <option value="Fr31">Fraccion 31</option>
                                      <option value="Fr32">Fraccion 32</option>
                                      <option value="Fr33">Fraccion 33</option>
                                      <option value="Fr34">Fraccion 34</option>
                                      <option value="Fr35">Fraccion 35</option>
                                      <option value="Fr36">Fraccion 36</option>
                                      <option value="Fr37">Fraccion 37</option>
                                      <option value="Fr38">Fraccion 38</option>
                                      <option value="Fr39">Fraccion 39</option>
                                      <option value="Fr40">Fraccion 40</option>
                                      <option value="Fr41">Fraccion 41</option>
                                      <option value="Fr42">Fraccion 42</option>
                                      <option value="Fr43">Fraccion 43</option>
                                      <option value="Fr44">Fraccion 44</option>
                                      <option value="Fr45">Fraccion 45</option>
                                      <option value="Fr46">Fraccion 46</option>
                                      <option value="Fr47">Fraccion 47</option>
                                      <option value="Fr48">Fraccion 48</option>
                                      <option value="Fr49">Fraccion 49</option>
                                      <option value="Fr50">Fraccion 50</option>
                                      <option value="Fr51">Fraccion 51</option>
                                      <option value="Fr52">Fraccion 52</option>
                                      <option value="Fr53">Fraccion 53</option>
                                      <option value="Fr54">Fraccion 54</option>
                                    </select>
                                    </div>
                                  </div>
                            </div>
                        </div>

                        <div class="col s12 m6 l3">
                            <div class="card horizontal">
                                  <div class="card-stacked">
                                    <div class="card-content">
                                        <h5>Año</h5>
                                    </div>
                                    <div class="card-action">
                                    <select class="browser-default" name="ano">
                                      <option value="" disabled selected>Selecciona</option>
                                      <option value="2020">2020</option>
                                      <option value="2021">2012</option>
                                      <option value="2019">2019</option>
                                      <option value="2018">2018</option>
                                    </select>
                                    </div>
                                  </div>
                            </div>
                        </div>

                    </div>


    <div class="file-field input-field">
      <div class="btn">
        <span>Selecciona el archivo</span>
        <input type="file" name="archivo" >
      </div>
      <div class="file-path-wrapper">
        <input class="file-path validate" type="text">
      </div>
    </div>
		<button id="sele_url"  class="waves-effect waves-light btn">Subir Archivo</button>
	</form>
