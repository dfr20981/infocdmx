function cocatena() {
    var ar = document.getElementById('articulo');
    var fr = document.getElementById('fraccion');
    var an = document.getElementById('ano');

    function name(sel) {
        var url = ar+'/'+fr+'/'+an+'/';
        
}
