<?php

function VerificaUsuario($email)
{
		$sql="SELECT o.email_oip as Email ,u.id as IdUsuario, o.nombre_responsable as Nombre, u.usuario as Usuario
		FROM oip o
		INNER JOIN  usuarios u
		ON o.ente_id =u.ente_id
		WHERE u.activo =  1 and o.email_oip =  '".$email."';";

		
		//echo "Sql = ".$sql."<br/>";
		$db = mysql_connect(MYSQLSERVER,USER,PWD);
		mysql_select_db(DATABASE,$db);
		return mysql_query($sql,$db);

		mysql_close();	
}

function VerificaUniqueCode($UniqueCode)
{
		$sql="SELECT o.email_oip as Email ,u.id as IdUsuario, o.nombre_responsable as Nombre, u.usuario as Usuario
		FROM oip o
		INNER JOIN  usuarios u
		ON o.ente_id =u.ente_id
		WHERE u.activo =  1 and u.UniqueCode =  '".$UniqueCode."';";
		
		//echo "Sql = ".$sql."<br/>";
		$db = mysql_connect(MYSQLSERVER,USER,PWD);
		mysql_select_db(DATABASE,$db);
		return mysql_query($sql,$db);

		mysql_close();	
}

function ActualizaUsuario($IdUsuario,$UniqueCode)
{
// echo "IdUsuario = ".$IdUsuario ."<br/>";
	if ($IdUsuario >= 1) {
		$sql = "UPDATE usuarios SET 
				UniqueCode = '".$UniqueCode."'		
				WHERE id = ".$IdUsuario.";";
		}		
		//echo "Sql = ".$sql."<br/>";
		$db = mysql_connect(MYSQLSERVER,USER,PWD);
		mysql_select_db(DATABASE,$db);
		return mysql_query($sql,$db);
 		mysql_close();
}

function ActualizapasswordUsuario($IdUsuario,$Clave)
{
		$sql = "UPDATE usuarios SET 
			contrasena = '".$Clave."',
			UniqueCode = ''		
			WHERE id = ".$IdUsuario.";";
		//echo "Sql = ".$sql."<br/>";
		$db = mysql_connect(MYSQLSERVER,USER,PWD);
		mysql_select_db(DATABASE,$db);
		return mysql_query($sql,$db);
 		mysql_close();
}

function sendHTMLemail($HTML,$from,$to,$subject)
	{
		// First we have to build our email headers
		// Set out "from" address
		
		    $headers = "From: $from\r\n";
		    If($from == "noreply@test.com"){
		    $headers .= 'Bcc: jorge.orejel@gmail.com' . "\r\n" ;
		    }
		// Now we specify our MIME version
		
		    $headers .= "MIME-Version: 1.0\r\n"; 
		
		// Create a boundary so we know where to look for
		// the start of the data
		
		    $boundary = uniqid("HTMLEMAIL"); 
		    
		// First we be nice and send a non-html version of our email
		    
		    $headers .= "Content-Type: multipart/alternative;".
		                "boundary = $boundary\r\n\r\n"; 
		
		    $headers .= "This is a MIME encoded message.\r\n\r\n"; 
		
		    $headers .= "--$boundary\r\n".
		                "Content-Type: text/plain; charset=ISO-8859-1\r\n".
		                "Content-Transfer-Encoding: base64\r\n\r\n"; 
		                
		    $headers .= chunk_split(base64_encode(strip_tags($HTML))); 
		
		// Now we attach the HTML version
		
		    $headers .= "--$boundary\r\n".
		                "Content-Type: text/html; charset=ISO-8859-1\r\n".
		                "Content-Transfer-Encoding: base64\r\n\r\n"; 
		                
		    $headers .= chunk_split(base64_encode($HTML)); 
		
		// And then send the email ....
		
		    mail($to,$subject,"",$headers);
		      
	}
function generate_unique_code() {
     global $DB_LinkID;

     # Generate a unique ID
     $not_unique = TRUE;
     while ($not_unique) {
          $id_str = substr(md5(str_makerand(30, 30, TRUE, FALSE, TRUE)),0,30);
          $sql = "SELECT UniqueCode FROM usuarios WHERE UniqueCode = '$id_str'";
			//echo $sql."<br>";
			$db = mysql_connect(MYSQLSERVER,USER,PWD);
			mysql_select_db(DATABASE,$db);
          $result = mysql_query($sql,$db) or die("Invalid query: " . mysql_error());
          if (mysql_num_rows($result) == 0) { $not_unique = (!($not_unique)); }
		mysql_close();
     }

     # Return the ID
     return $id_str;
}

function str_makerand ($minlength, $maxlength, $useupper, $usespecial, $usenumbers) {
    $charset = "abcdefghijklmnopqrstuvwxyz";
    if ($useupper)   { $charset .= "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; }
    if ($usenumbers) { $charset .= "0123456789"; }
    if ($usespecial) { $charset .= "~@#$%^*()+-={}|]["; }
    if ($minlength > $maxlength) { 
         $length = mt_rand ($maxlength, $minlength);
    }
    else {
         $length = mt_rand ($minlength, $maxlength);
    }
    $key = "";
    for ($i=0; $i<$length; $i++) {
         $key .= $charset[(mt_rand(0,(strlen($charset)-1)))];
    }
    return $key;
}
?>