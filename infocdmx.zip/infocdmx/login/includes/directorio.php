<?php 

function RegresaTodosLosEntesActivos()
{
		$sql="SELECT e.id,e.direccion_id,e.nombre,e.catalogo,e.activo,e.url_web,e.url_transparencia,e.url_logo,d.calle,d.numero,d.piso,d.oficina,d.colonia,d.delegacion,d.cp FROM entes e  
		INNER JOIN  direcciones d
		ON e.direccion_id =d.id
		WHERE activo = 1  ;";
		//echo "Sql = ".$sql."<br/>";

		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);	
}

function Regresa_Ente_Id($id)
{
		$sql="SELECT e.id,e.direccion_id,e.nombre,e.catalogo,e.activo,e.url_web,e.url_transparencia,e.url_logo,d.calle,d.numero,d.piso,d.oficina,d.colonia,d.delegacion,d.cp FROM entes e  
		INNER JOIN  direcciones d
		ON e.direccion_id =d.id
		WHERE e.id =  $id ;";
		//echo "id = $id";
		//echo "Sql = ".$sql."<br/>";
		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);
}

function Regresa_oip_Id($id)
{
		$sql="SELECT o.id,o.ente_id,o.direccion_id,o.titulo_responsable,o.nombre_responsable,o.cargo_responsable,o.puesto_responsable,o.telefono_responsable,o.extencion1_responsable,o.extencion2_responsable,o.celular_responsable,o.telefono_oip,o.extencion_oip1,o.extencion_oip2,o.email1_responsable,o.email2_responsable,o.email3_responsable,o.email_oip,o.email_oip2,o.email_oip3,o.titulo_operativo,o.nombre_operativo,o.cargo_operativo,o.telefono_operativo,o.extencion1_operativo,o.extencion2_operativo,o.email1_operativo,o.email2_operativo,d.calle,d.numero,d.piso,d.oficina,d.colonia,d.delegacion,d.cp FROM oip o
		INNER JOIN  direcciones d
		ON o.direccion_id =d.id
		WHERE o.id =  $id ;";
		//echo "id = $id";
		//echo "Sql = ".$sql."<br/>";
		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);	
}

function Regresa_Titular_Id($id)
{
		$sql="SELECT t.id,t.ente_id,t.direccion_id,t.correspondencia_id,t.titulo_titular,t.nombre_titular,t.cargo_titular,t.telefono_titular,t.extencion1_titular,t.extencion2_titular,t.telefono2_titular,t.telefono3_titular,t.fax_titular,t.email1_titular,t.email2_titular,t.nombre_asesor,t.titulo_asesor,t.telefono_asesor,t.extencion_asesor,t.nombre_secretario,t.titulo_secretario,t.telefono_secretario,t.extencion_secretario,
		d1.calle,d1.numero,d1.piso,d1.oficina,d1.colonia,d1.delegacion,d1.cp,
		d2.calle as 'calle_c',d2.numero 'numero_c',d2.piso 'piso_c',d2.oficina 'oficina_c',d2.colonia 'colonia_c',d2.delegacion 'delegacion_c',d2.cp 'cp_c'
		FROM titulares t
		INNER JOIN  direcciones d1  ON t.direccion_id =d1.id
		INNER JOIN  direcciones d2  ON t.correspondencia_id =d2.id		
		WHERE t.id =  $id ;";
		//echo "id = $id";
		//echo "Sql = ".$sql."<br/>";
		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);	
}

function Regresa_Comite_Id($id)
{
		$sql="SELECT c.id,c.ente_id,c.direccion_id,c.titulo,c.nombre,c.puesto,c.cargo,c.email,c.telefono1,c.extencion1,c.telefono2,c.extencion2,d.calle,d.numero,d.piso,d.oficina,d.colonia,d.delegacion,d.cp FROM comite c  
		INNER JOIN  direcciones d
		ON c.direccion_id =d.id
		WHERE c.ente_id =  $id ;";
		//echo "Sql = ".$sql."<br/>";
		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);	
}


function Regresa_usuario_ente($ente_id)
{
$sql="SELECT id,ente_id,usuario,rol FROM usuarios WHERE ente_id = $ente_id ;";
		//echo "Sql = ".$sql."<br/>";
		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);	
}


function Ente_Id()
{
		$sql="SELECT id,nombre FROM `entes`;";
		//echo "id = $id";
		//echo "Sql = ".$sql."<br/>";
		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);	
} 





function traer_integrantes_comite($Id)
{
		$sql="SELECT  d.cp FROM comite c  
		INNER JOIN  direcciones d
		ON c.direccion_id =d.id
		WHERE c.ente_id =  $id ;";
		//echo "Sql = ".$sql."<br/>";
		$db = mysqli_connect(MYSQLSERVER,USER,PWD);
		mysqli_select_db($db, DATABASE);
		//mysqli_set_charset($db, "utf8");
		return mysqli_query($db, $sql);
		mysqli_close($db);	
}



function Maxtol1()
{
		$sql=" SELECT max(comites) as MaxMiembrosComitesXente FROM ( select count(id) as comites FROM comite group by ente_id ) t ;";
	//	echo "Sql = ".$sql."<br/>";

	$db = mysqli_connect(MYSQLSERVER,USER,PWD);
			mysqli_select_db($db, DATABASE);
	//mysqli_set_charset($db, "utf8");
		$rs = mysqli_query($db, $sql);
		if ($row = mysqli_fetch_array($rs))
		{
			return $row['MaxMiembrosComitesXente'];
		}
		else
		{
			return 0;
		}
		mysqli_close($db);

}




function DrawComboOnClick($RecordSet,$SelectName,$PreSelectedText,$SelectId,$FieldId,$FieldShow,$Javascript)
{
     if(strlen($SelectId)== 0 || is_null($SelectId))
     {
          $SelectId = 0;
     }
     if ($myrow = mysqli_fetch_array($RecordSet))
     {
          //recordset lleno
          echo "<SELECT  class='form-control' name='".$SelectName."'  onchange='".$Javascript."'>";
          if($SelectId == 0)
          {
               echo "<OPTION value='' selected>";
               echo $PreSelectedText;
               echo "</OPTION>";
          }
          else
          {
               echo "<OPTION value=''>";
               echo $PreSelectedText;
               echo "</OPTION>";
          }
          do
          {
               echo "<OPTION value='".$myrow[$FieldId]."'";
               if($myrow[$FieldId] == $SelectId)
                    echo " selected";
               echo ">";
               echo $myrow[$FieldShow];
               echo "</OPTION>";
          }
          while ($myrow = mysqli_fetch_array($RecordSet));
          echo "</SELECT>";
     }
     else
     {
          //recordset vacio
          echo "<SELECT  class='form-control' name='".$SelectName."' size='1' >";
               echo "<OPTION value='' selected>";
               echo $PreSelectedText;
               echo "</OPTION>";
          echo "</SELECT>";
     }
}


function comparaDirecciones($IdDireccienEnte, $IdDireccionX)

{
	

 if ($IdDireccienEnte == $IdDireccionX){

 	return 'crear';
 } else {
 	return 'actualizar';
 }

}


 ?>
