
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-62089217-1', 'auto');
  ga('send', 'pageview');

</script>
    
    <!--FOOTER-->
    <footer>
        <div class="contenedorFooter">        
            <p class="direccion">Instituto de Transparencia, Acceso a la Información Pública, Protección de Datos Personales y Rendición de Cuentas de la Ciudad de México</p>
            
           <p>La Morena 865 Col. Narvarte Poniente C.P. 03020, Ciudad de México, México <br>
           Tel.: (55) 5636 2120, Fax (55) 5639 2051</p>
        </div>
    </footer> 