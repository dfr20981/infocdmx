<?php

		function clean($str) {
		$str = trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		$db = mysql_connect(MYSQLSERVER,USER,PWD);
		mysql_select_db(DATABASE,$db);
		//return mysql_query($sql,$db);
		return mysql_real_escape_string($str);
		mysql_close();	
	}
	
?>