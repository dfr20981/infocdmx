<?php

include_once 'includes/config.php';
include_once 'includes/seguridad.php';
//var_dump($_POST);
//var_dump($_SESSION); // no porque cuando este el administrador podriamos regarla


$usuario = $_SESSION['SESS_USER'] ;
$contra = clean($_POST['contrasena']);
$contrasena = md5 ($contra);


	$sql = "UPDATE usuarios SET contrasena =$contrasena  WHERE usuario = $usuario;";

			//echo "Sql = ".$sql."<br/>";
			$db = mysqli_connect(MYSQLSERVER,USER,PWD,DATABASE);
			//mysqli_query("SET NAMES 'utf8'", $db);
			mysqli_set_charset($db, 'utf-8');
			mysqli_query($db, $sql);
			mysqli_close($db);


echo 'correcto';
?>