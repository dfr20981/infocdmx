<?php

	session_cache_limiter("must-revalidate");
	session_cache_expire(30);

  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Some time in the past
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
  header("Cache-Control: no-store, no-cache, must-revalidate");
  header("Cache-Control: post-check=0, pre-check=0", false);
  header("Pragma: no-cache");
	ob_start("ob_gzhandler");

	session_start();

	/*===================== Conexion MySql y Constantes  ===========================
		0 = Desarrollo - Localhost
		1 = Produccion
	================================================================================*/
		define("PROD","0");

	/*========================== Mostrar Errores =====================================
		0 = No Mostrar errores (Siempre debera estar en Produccion y Demo)
		1 = Mostrar todos los errores
	================================================
	================================*/
		$error = 1;

	if(PROD == 1){
		# PRODUCCCION

		/*========================== DataBase =====================================*/
		define("MYSQLSERVER", "192.168.40.101");
	    define("USER","monty");
	    define("PWD","p4ssT3rr#56");
	    define("DATABASE","infodf_directorio");

	    /*========================== directorio base =====================================*/
		define("BASESITE","http://www.infodf.org.mx/directorio");


		/*========================== Analitics =======================================*/
		$analitics = "<script>
				  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
				  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
				  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
				  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

				  ga('create', 'UA-62089217-1', 'auto');
				  ga('send', 'pageview');

				</script>";


	} else {

			# DESARROLLO
			/*========================== DataBase =====================================*/
			//define("MYSQLSERVER", "192.168.0.231");
			define("MYSQLSERVER", "localhost");
			define("USER","root");
			define("PWD","");
			define("DATABASE","GVOT");
	    /*========================== directorio base =====================================*/
		define("BASESITE","http://localhost");


		/*========================== Analitics =======================================*/
			$analitics = '';
	}

	if ($error)
		{
			error_reporting (-1) ; // Mostrar todos los errores
			error_reporting(E_ALL);
			ini_set('display_errors',1);
		} else
		{
			error_reporting (0) ; // No muestra errores
			ini_set ( "display_errors", 0 );
		}

	// consulta publica

			$hostname_infodb = MYSQLSERVER;
			$database_infodb = DATABASE;
			$username_infodb = USER;
			$password_infodb = PWD;

			$mysqli = new mysqli($hostname_infodb,$username_infodb,$password_infodb, $database_infodb);
			if ($mysqli->connect_errno) {
				    printf("Falló la conexión: %s\n", $mysqli->connect_error);
				    exit();
				}

	// Funcion para saber la Ip del usuario
	function getRealIpAddr()
	{
	    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
	    {      $ip=$_SERVER['HTTP_CLIENT_IP'];
	    }    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
	    {      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];	    }
	    else  {     $ip=$_SERVER['REMOTE_ADDR'];    }
	    return $ip;
	}

	// configuracion para horario de ciudad de mexico
	date_default_timezone_set('America/Mexico_City');
