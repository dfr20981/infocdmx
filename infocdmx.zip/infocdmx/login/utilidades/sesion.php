<?php
	session_start();
	 
	if(isset($_SESSION['SESS_ERROR'])){
		if($_SESSION['SESS_ERROR']==0){
			echo '1';
		}
    }
    

    /*
	if(isset($_SESSION['SESS_MEMBER_ID'])){
		echo 1;
	}
	*/
	/*else{
		echo 2;
	}*/
	
/*
	session_start();

	// print_r($_SESSION);

	if (isset($_SESSION['SESS_MEMBER_ID']) || (trim($_SESSION['SESS_MEMBER_ID']) != '')) {
		header("location: inicio.php");
		exit();
	}
	// Nombre de la pagina
	define("PAGE", "Sistema");
	// configuracion
	include_once 'main/config.php';
	// seguridad
	// include_once 'security.php';

	if (isset($HTTP_POST_VARS['Msg'])) { $Msg = $HTTP_POST_VARS['Msg']; }
	 else { if (isset($_GET['Msg'])) { $Msg = $_GET['Msg']; } else { $Msg = ''; }}
*/	 
?>
