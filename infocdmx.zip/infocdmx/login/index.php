<?php
    require('utilidades/sesion.php') ;
?>
<!DOCTYPE html>
<html lang="es-MX">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Carga de Archivos</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="css/reset.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/movil.css" />


        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400italic,600,600italic' rel='stylesheet' type='text/css'>

        <script src="js/jquery-1.10.1.min.js"></script>
        <script src="js/modernizr.custom.js"></script>

        <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <script src="js/script.js"></script>
    </head>

    <body>
         <?php /*echo $analitics; */?>
        <header>
                <div class="container-fluid">
                    <div id="contenedorHeader">
                        <div class="row">
                            <div class="col-md-12">
                                <div id="logo">
                                    <h1>
                                       <a href="http://www.infodf.org.mx/"><img src="images/logo_infodf.png" alt="InfoDF"/></a>
                                    </h1>
                                    <h2>Carga de Archivos</h2>
                                </div>
                            </div>
                        </div>
                    <!-- ROW-->
                    </div>
                </div>
            <!-- container-fluid-->
        </header>

<div class="clearfix"></div>
    <div id="contenedorPrincipal">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
					<?php
                        if (isset($_SESSION['SESS_MSG'])){
                            echo  $_SESSION['SESS_MSG'];
                        }
                    ?>
					<form name="loginForm" action="Control/control.php" method="post" >

                    <fieldset class="cuadro_datos">
                        <div class="form-group">
                            <input type="text" id="user" name="user" value="" placeholder="Usuario" class="form-control input-lg" required autocomplete="off" />
                        </div>

                        <div class="form-group">
                            <input type="password" id="pws" name="pws" value="" placeholder="contrasena" class="form-control input-lg" required autocomplete="off"/>
                        </div>

                            <div id="botones">
                       			<input class="btnMas" type="submit" name="Submit" value="Entrar" />
                            </div>
                            <br></br>
                            <center><a align="center" href="password/" id="forgot-password-link" tabindex="3">¿Olvidó su contraseña?</a></center>
                    </fieldset>
					</form>
                </div>
            </div>
        </div>
    </div>

    <!--FOOTER-->
    <footer>
        <div class="contenedorFooter">
            <p class="direccion">Instituto de Acceso a la Informaci&oacute;n P&uacute;blica y Protecci&oacute;n de Datos Personales del Distrito Federal</p>
            <p>La Morena 865 Col. Narvarte Poniente Local 1 C.P. 03020, M&eacute;xico D.F.,Tel.: (55) 5636 2120, Fax (55) 5639 2051.</p>
        </div>
    </footer>

<script src="js/bootstrap.min.js"></script>

    </body>
</html>
