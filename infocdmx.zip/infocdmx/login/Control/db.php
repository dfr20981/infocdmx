<?php
	class Conexion{
	 public static function con(){
	   	$serverName = "localhost";

    	$conn =  mysqli_connect("localhost","root","");


		return $conn;
	 }
	}
?>
