DELIMITER $$
DROP PROCEDURE IF EXISTS 'sp_upArchi';
CREATE
/*[DEFINER = { user | CURRENT_USER }]*/
PROCEDURE sp_upArchi
(   
    @idHiperVinculo INT(255),
    @nombreArchivo  VARCHAR (1000),
    @anio TINYINT(4),
    @articulo TINYINT(4),
    @fraccion VARCHAR (100),
    @idTrimestre TINYINT(4),
    @url VARCHAR(255),
    @fechaCreacion DATETIME,
    @fechaUltActualizacion DATETIME ,
    @idUnidadAdmva int(11),
    @activo CHAR (1),
    @usuarioUltMov VARCHAR(100),
    @tipoUltimoMov CHAR (1) 
)
BEGIN
    

    INSERT INTO Hipervinculo(
        idHiperVinculo,
        nombreArchivo,
        anio,
        articulo,
        fraccion,
        idTrimestre,
        url,
        fechaCreacion,
        fechaUltActualizacion,
        idUnidadAdmva,
        activo,
        usuarioUltMov,
        tipoUltimoMov
        )
    SELECT 
    auto_increment,
    @nombreArchivo,
    @anio,
    @articulo,
    @fraccion,
    @idTrimestre,
    CONCAT('https://infocdmx.org.mx/LTAIPRC-2016-OT','/' ,@url),
    @fechaCreacion = now(),
    null,
    @idUnidadAdmva,
    '1',
    @usuarioUltMov,
    '1';
END;
$$
DELIMITER // 