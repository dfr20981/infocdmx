delimiter $$
DROP PROCEDURE IF EXISTS 'up_personal'$$
CREATE PROCEDURE 'up_personal'(

)
<<<<<<< HEAD
BEGIN

=======
>>>>>>> 1eabcec2b0088d37cffc316ca58bca97d1c3f079
$$
delimiter //
