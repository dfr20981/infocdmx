DROP PROCEDURE IF EXISTS 'sp_delteusu'
CREATE
/*[DEFINER = { user | CURRENT_USER }]*/
PROCEDURE 'sp_delteusu'
BEGIN

DECLARE @id INT(11),
        @usrNomre VARCHAR(150),
        @idUnidadAdmva INT(11),
        @activo CHAR(1),
        @correo VARCHAR(100),
        @pwdUsuario VARCHAR(200);
DELETE FROM  Usuario WHERE  id,usrNomre,idUnidadAdmva,activo,correo,pwdUsuario;
END;