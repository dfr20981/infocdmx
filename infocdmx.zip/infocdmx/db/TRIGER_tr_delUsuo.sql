CREATE
/*[DEFINER = { user | CURRENT_USER }]*/
TRIGGER tg_delUsu 
ON Usuario
AFTER DELETE 
as
DECLARE @id INT(11),
        @usrNomre VARCHAR(150),
        @idUnidadAdmva INT(11),
        @activo CHAR(1),
        @correo VARCHAR(100),
        @pwdUsuario VARCHAR(200);

INSERT INTO Usuario_historico(id,usrNomre,idUnidadAdmva,activo,correo,pwdUsuario)
VALUES(@id,@usrNomre,@idUnidadAdmva,@activo,@correo,@pwdUsuario)
FOR EACH ROW BEGIN

END;