CREATE TABLE `UnidadAdmva` (
`idUnidadAdmva` integer NOT NULL,
`nombreCorto` char(20) NOT NULL,
`nombre` varchar(200) NOT NULL,
PRIMARY KEY (`idUnidadAdmva`) 
);
CREATE TABLE `Usuario` (
`id` integer(11) NOT NULL,
`usrNombre` varchar(150) NOT NULL,
`idUnidadAdmva` integer NOT NULL,
`activo` char(1) NOT NULL COMMENT '0 activo, 1 inactivo',
`correo` varchar(100) NOT NULL,
`pwdUsuario` varchar(200) NOT NULL
);
CREATE TABLE `Hipervinculo` (
`idHiperVinculo` integer(255) NOT NULL,
`nombreArchivo` varchar(1000) NOT NULL,
`anio` tinyint NOT NULL,
`articulo` tinyint NOT NULL,
`fraccion` varchar(100) NULL,
`idTrimestre` tinyint NOT NULL COMMENT 'T01, T02, T03, T04 posibles valores',
`url` varchar(1000) NOT NULL,
`fechaCreacion` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
`fechaUltActualizacion` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
`idUnidadAdmva` integer NOT NULL,
`activo` char(1) NOT NULL COMMENT '0 Activo 1 Baja',
`usuarioUltMov` varchar(100) NOT NULL,
`tipoUltimoMov` char(1) NOT NULL COMMENT '0 Creado, 1 Actualizado, 2 Eliminado',
PRIMARY KEY (`idHiperVinculo`) 
);
CREATE TABLE `Articulo` (
`idArticulo` integer NOT NULL,
`nombre` varchar(150) NOT NULL,
PRIMARY KEY (`idArticulo`) 
);
CREATE TABLE `Fraccion` (
`idFraccion` integer NOT NULL,
`nombreFrac` varchar(150) NOT NULL,
`idArticulo` integer NOT NULL,
PRIMARY KEY (`idFraccion`) 
);
CREATE TABLE `Permisos` (
`idPermiso` integer NOT NULL,
`idUnidadAdmva` integer NOT NULL,
`activo` char(1) NOT NULL COMMENT '0 activo, 1 inactivo',
`idArticulo` integer NOT NULL,
`idFraccion` integer NULL,
`idAnioNormatividad` tinyint NOT NULL,
PRIMARY KEY (`idPermiso`) 
);
CREATE TABLE `anioNormatividad` (
`idAnioNormatividad` tinyint(255) NOT NULL,
`descripción` char(4) NOT NULL,
PRIMARY KEY (`idAnioNormatividad`) 
);
CREATE TABLE `Trimestre` (
`idTrimestre` tinyint NOT NULL,
`nombre` varchar(100) NOT NULL,
`claveTrimestre` varchar(20) NOT NULL COMMENT 'Clave a usar en la ruta o url al archivo',
PRIMARY KEY (`idTrimestre`) 
);

ALTER TABLE `Fraccion` ADD CONSTRAINT `idArticulo` FOREIGN KEY (`idArticulo`) REFERENCES `Articulo` (`idArticulo`);
ALTER TABLE `Usuario` ADD CONSTRAINT `idUnidadAdmva` FOREIGN KEY (`idUnidadAdmva`) REFERENCES `UnidadAdmva` (`idUnidadAdmva`);
ALTER TABLE `Permisos` ADD CONSTRAINT `fkUnidadAdmva` FOREIGN KEY (`idUnidadAdmva`) REFERENCES `UnidadAdmva` (`idUnidadAdmva`);
ALTER TABLE `Hipervinculo` ADD CONSTRAINT `hipfkUnidadAdmva` FOREIGN KEY (`idUnidadAdmva`) REFERENCES `UnidadAdmva` (`idUnidadAdmva`);
ALTER TABLE `Permisos` ADD CONSTRAINT `fkArticulo` FOREIGN KEY (`idArticulo`) REFERENCES `Articulo` (`idArticulo`);
ALTER TABLE `Permisos` ADD CONSTRAINT `fkFraccion` FOREIGN KEY (`idFraccion`) REFERENCES `Fraccion` (`idFraccion`);
ALTER TABLE `Permisos` ADD CONSTRAINT `fkAnioNormatividad` FOREIGN KEY (`idAnioNormatividad`) REFERENCES `anioNormatividad` (`idAnioNormatividad`);
ALTER TABLE `Hipervinculo` ADD CONSTRAINT `fkTrimestre` FOREIGN KEY (`idTrimestre`) REFERENCES `Trimestre` (`idTrimestre`);

